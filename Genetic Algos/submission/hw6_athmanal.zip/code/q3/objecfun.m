function f = objecfun(x)
f = (4*(0.0025*pi*275*((x(1)+2*x(2))^2-x(1)^2))/4)+2*x(1)
end